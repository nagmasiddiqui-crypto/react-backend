# Authentication Package - All Code Files

This document contains all the code you need to copy for the authentication system.

---

## 1. models/userSchema.js

```javascript
import mongoose from "mongoose";
import validator from "validator";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

const userSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      lowercase: true,
      validate: [validator.isEmail, "Please provide a valid email"],
    },

    password: {
      type: String,
      required: [true, "Password is required"],
      minLength: [8, "Password must be at least 8 characters"],
      select: false,
    },

    rememberMe: {
      type: Boolean,
      default: false,
    },

    role: {
      type: String,
      enum: ["User", "Admin"],
      default: "User",
    },

    avatar: {
      public_id: String,
      url: String,
    },
  },
  {
    timestamps: true,
  }
);

/* Hash password before save */
userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  this.password = await bcrypt.hash(this.password, 10);
});

/*  Compare password */
userSchema.methods.comparePassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

/*  Generate JWT */
userSchema.methods.generateJsonWebToken = function () {
  return jwt.sign(
    { id: this._id },
    process.env.JWT_SECRET_KEY,
    {
      expiresIn: process.env.JWT_EXPIRES || "7d",
    }
  );
};

export const User = mongoose.model("User", userSchema);
```

---

## 2. controller/userController.js

```javascript
import { User } from "../models/userSchema.js";
import { generateToken } from "../utils/jwtToken.js";

/* ================= REGISTER ================= */
export const register = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and password are required",
      });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(409).json({
        success: false,
        message: "User already exists",
      });
    }

    const user = await User.create({ email, password });

    // ✅ USE JWT UTILITY
    generateToken(user, "User registered successfully", 201, res);

  } catch (error) {
    next(error);
  }
};

/* ================= LOGIN ================= */
export const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and password are required",
      });
    }

    const user = await User.findOne({ email }).select("+password");

    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Invalid credentials",
      });
    }

    const isMatch = await user.comparePassword(password);

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: "Invalid credentials",
      });
    }

    // ✅ USE JWT UTILITY
    generateToken(user, "Login successful", 200, res);

  } catch (error) {
    next(error);
  }
};
```

---

## 3. router/userRouter.js

```javascript
import express from "express";
import { register, login } from "../controller/userController.js";

const router = express.Router();

router.post("/register", register);
router.post("/login", login);

export default router;
```

---

## 4. utils/jwtToken.js

```javascript
export const generateToken = (user, message, statusCode, res) => {
  const token = user.generateJsonWebToken();

  res
    .status(statusCode)
    .cookie("token", token, {
      expires: new Date(
        Date.now() +
          (process.env.COOKIE_EXPIRE || 7) * 24 * 60 * 60 * 1000
      ),
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
    })
    .json({
      success: true,
      message,
      user: {
        id: user._id,
        email: user.email,
      },
      token,
    });
};
```

---

## 5. middlewares/errorMiddleware.js

```javascript
export const errorMiddleware = (err, req, res, next) => {
  // Default values
  err.statusCode = err.statusCode || 500;
  err.message = err.message || "Internal Server Error";

  // MongoDB duplicate key error
  if (err.code === 11000) {
    err.message = `Duplicate ${Object.keys(err.keyValue)} entered`;
    err.statusCode = 400;
  }

  // JWT invalid error
  if (err.name === "JsonWebTokenError") {
    err.message = "Invalid JSON Web Token";
    err.statusCode = 400;
  }

  // JWT expired error
  if (err.name === "TokenExpiredError") {
    err.message = "JSON Web Token has expired";
    err.statusCode = 400;
  }

  // ✅ SEND RESPONSE
  res.status(err.statusCode).json({
    success: false,
    message: err.message,
  });
};
```

---

## 6. database/DBconnection.js

```javascript
import mongoose from "mongoose";

export const DBconnection = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log("✅ MongoDB connected:", conn.connection.name);
  } catch (error) {
    console.error("❌ MongoDB connection failed:", error);
  }
};
```

---

## 7. Optional: middlewares/authMiddleware.js

```javascript
import jwt from "jsonwebtoken";
import { User } from "../models/userSchema.js";

export const isAuthenticated = async (req, res, next) => {
  try {
    const token = req.cookies.token || req.headers.authorization?.split(" ")[1];

    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Please login to access this resource",
      });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET_KEY);
    req.user = await User.findById(decoded.id);
    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: "Invalid or expired token",
    });
  }
};
```

---

## 8. Example app.js Setup

```javascript
import express from "express";
import { config } from "dotenv";
import cors from "cors";
import cookieParser from "cookie-parser";
import userRouter from "./router/userRouter.js";
import { errorMiddleware } from "./middlewares/errorMiddleware.js";

// Load environment variables
config();

const app = express();

// Body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS
app.use(
  cors({
    origin: process.env.FRONTEND_URL || "http://localhost:3000",
    credentials: true,
  })
);

// Cookie parser
app.use(cookieParser());

// Routes
app.use("/api/v1/user", userRouter);

// Error handler (must be last)
app.use(errorMiddleware);

export default app;
```

---

## 9. Example server.js Setup

```javascript
import dotenv from "dotenv";
import mongoose from "mongoose";
import app from "./app.js";

dotenv.config();

// MongoDB connection
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("✅ MongoDB connected");

    const PORT = process.env.PORT || 4000;
    app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
    });
  })
  .catch((err) => {
    console.error("❌ MongoDB connection failed:", err.message);
    process.exit(1);
  });
```

---

## 10. package.json Dependencies

```json
{
  "dependencies": {
    "bcrypt": "^5.1.1",
    "cookie-parser": "^1.4.6",
    "cors": "^2.8.5",
    "dotenv": "^16.4.5",
    "express": "^4.18.3",
    "jsonwebtoken": "^9.0.2",
    "mongoose": "^8.2.1",
    "validator": "^13.11.0"
  }
}
```

---

## 11. .env Example

```env
PORT=4000
MONGO_URI=mongodb://localhost:27017/your-database-name
JWT_SECRET_KEY=your-secret-key-here-min-32-characters
JWT_EXPIRES=7d
COOKIE_EXPIRE=7
NODE_ENV=development
FRONTEND_URL=http://localhost:3000
```

---

## Quick Copy Checklist

1. ✅ Copy `models/userSchema.js`
2. ✅ Copy `controller/userController.js`
3. ✅ Copy `router/userRouter.js`
4. ✅ Copy `utils/jwtToken.js`
5. ✅ Copy `middlewares/errorMiddleware.js`
6. ✅ Copy `database/DBconnection.js` (optional, or use server.js approach)
7. ✅ Update your `app.js` with middleware and routes
8. ✅ Update your `server.js` with MongoDB connection
9. ✅ Install dependencies: `npm install express mongoose bcrypt jsonwebtoken validator cookie-parser cors dotenv`
10. ✅ Create `.env` file with required variables

---

## API Endpoints

- **POST** `/api/v1/user/register` - Register new user
- **POST** `/api/v1/user/login` - Login user

Both endpoints return:
- `success`: boolean
- `message`: string
- `user`: { id, email }
- `token`: JWT token (also set as HTTP-only cookie)

