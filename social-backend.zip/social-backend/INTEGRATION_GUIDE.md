# Login & Signup Integration Guide

This guide explains how to integrate the authentication (login/signup) functionality from this backend into another project.

## 📋 Components Overview

The authentication system consists of the following components:

1. **User Model** (`models/userSchema.js`) - MongoDB schema with password hashing
2. **User Controller** (`controller/userController.js`) - Register and login logic
3. **User Router** (`router/userRouter.js`) - API routes
4. **JWT Utility** (`utils/jwtToken.js`) - Token generation and cookie setting
5. **Error Middleware** (`middlewares/errorMiddleware.js`) - Error handling
6. **Database Connection** (`database/DBconnection.js`) - MongoDB connection

---

## 📦 Required Dependencies

Install these packages in your target project:

```bash
npm install express mongoose bcrypt jsonwebtoken validator cookie-parser cors dotenv
```

---

## 🔧 Step-by-Step Integration

### Step 1: Copy Required Files

Copy the following files to your target project:

```
your-project/
├── models/
│   └── userSchema.js
├── controller/
│   └── userController.js
├── router/
│   └── userRouter.js
├── utils/
│   └── jwtToken.js
├── middlewares/
│   └── errorMiddleware.js
└── database/
    └── DBconnection.js
```

### Step 2: Set Up Environment Variables

Add these to your `.env` file:

```env
PORT=4000
MONGO_URI=mongodb://localhost:27017/your-database-name
JWT_SECRET_KEY=your-secret-key-here-min-32-characters
JWT_EXPIRES=7d
COOKIE_EXPIRE=7
NODE_ENV=development
```

**Important:** Change `JWT_SECRET_KEY` to a secure random string in production!

### Step 3: Update Your Main App File

In your main Express app file (e.g., `app.js` or `index.js`), add:

```javascript
import express from "express";
import { config } from "dotenv";
import cors from "cors";
import cookieParser from "cookie-parser";
import userRouter from "./router/userRouter.js";
import { errorMiddleware } from "./middlewares/errorMiddleware.js";

// Load environment variables
config();

const app = express();

// Body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS (adjust origins as needed)
app.use(
  cors({
    origin: process.env.FRONTEND_URL || "http://localhost:3000",
    credentials: true,
  })
);

// Cookie parser
app.use(cookieParser());

// Routes
app.use("/api/v1/user", userRouter);

// Error handler (must be last)
app.use(errorMiddleware);

export default app;
```

### Step 4: Set Up Database Connection

In your server entry point (e.g., `server.js`):

```javascript
import dotenv from "dotenv";
import mongoose from "mongoose";
import app from "./app.js";

dotenv.config();

// MongoDB connection
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("✅ MongoDB connected");

    const PORT = process.env.PORT || 4000;
    app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
    });
  })
  .catch((err) => {
    console.error("❌ MongoDB connection failed:", err.message);
    process.exit(1);
  });
```

---

## 📡 API Endpoints

After integration, you'll have these endpoints:

### Register User
```
POST /api/v1/user/register
Content-Type: application/json

Body:
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "success": true,
  "message": "User registered successfully",
  "user": {
    "id": "user_id",
    "email": "user@example.com"
  },
  "token": "jwt_token_here"
}
```

### Login User
```
POST /api/v1/user/login
Content-Type: application/json

Body:
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Login successful",
  "user": {
    "id": "user_id",
    "email": "user@example.com"
  },
  "token": "jwt_token_here"
}
```

**Note:** The token is also set as an HTTP-only cookie named `token`.

---

## 🔐 Features Included

✅ Email validation  
✅ Password hashing with bcrypt  
✅ JWT token generation  
✅ HTTP-only cookie support  
✅ Duplicate email prevention  
✅ Error handling middleware  
✅ Password comparison method  

---

## 🎯 Optional: Add Authentication Middleware

If you want to protect routes, create an authentication middleware:

**Create `middlewares/authMiddleware.js`:**

```javascript
import jwt from "jsonwebtoken";
import { User } from "../models/userSchema.js";

export const isAuthenticated = async (req, res, next) => {
  try {
    const token = req.cookies.token || req.headers.authorization?.split(" ")[1];

    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Please login to access this resource",
      });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET_KEY);
    req.user = await User.findById(decoded.id);
    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: "Invalid or expired token",
    });
  }
};
```

**Usage in routes:**
```javascript
import { isAuthenticated } from "../middlewares/authMiddleware.js";

router.get("/profile", isAuthenticated, (req, res) => {
  res.json({ user: req.user });
});
```

---

## 🚨 Important Notes

1. **Security:** Always use a strong `JWT_SECRET_KEY` in production
2. **CORS:** Update CORS origins to match your frontend URL
3. **Database:** Ensure MongoDB is running and accessible
4. **Password:** Minimum 8 characters required
5. **Email:** Must be a valid email format (validated automatically)

---

## 🧪 Testing

Test the endpoints using:

**cURL:**
```bash
# Register
curl -X POST http://localhost:4000/api/v1/user/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'

# Login
curl -X POST http://localhost:4000/api/v1/user/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}' \
  -c cookies.txt
```

**Postman/Thunder Client:**
- Set method to POST
- Add JSON body with email and password
- For login, check cookies in response

---

## 📝 File Structure Reference

```
your-project/
├── config/
│   └── config.env (or .env)
├── models/
│   └── userSchema.js
├── controller/
│   └── userController.js
├── router/
│   └── userRouter.js
├── utils/
│   └── jwtToken.js
├── middlewares/
│   ├── errorMiddleware.js
│   └── authMiddleware.js (optional)
├── database/
│   └── DBconnection.js
├── app.js
└── server.js
```

---

## ✅ Integration Checklist

- [ ] Copy all required files
- [ ] Install dependencies
- [ ] Set up environment variables
- [ ] Configure Express app with middleware
- [ ] Set up MongoDB connection
- [ ] Test register endpoint
- [ ] Test login endpoint
- [ ] Update CORS origins for your frontend
- [ ] Change JWT_SECRET_KEY to a secure value

---

## 🆘 Troubleshooting

**MongoDB connection error:**
- Check if MongoDB is running
- Verify MONGO_URI in .env file
- Check network/firewall settings

**JWT errors:**
- Ensure JWT_SECRET_KEY is set
- Check token expiration settings

**CORS errors:**
- Update CORS origin to match your frontend URL
- Ensure credentials: true is set

**Duplicate email error:**
- This is expected behavior - email must be unique

---

## 📞 Support

If you encounter issues:
1. Check console logs for error messages
2. Verify all environment variables are set
3. Ensure all dependencies are installed
4. Check MongoDB connection status

